using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;

using System.Threading;
using System.Windows.Forms;

public struct RowChoice
{
    public int Row;
    public bool IsNew;
    public RowChoice(int row, bool isNew) { Row = row; IsNew = isNew; }
}

public static class DataRules
{
    public static DateTime? ParseDate(object value, bool date1904)
    {
        if (value == null || value is bool) return null;
        if (value is DateTime) return ((DateTime)value).Date;
        if (value is double || value is int || value is float || value is decimal)
        {
            try { return DateTime.FromOADate(Convert.ToDouble(value) + (date1904 ? 1462 : 0)).Date; }
            catch (ArgumentException) { return null; }
        }
        DateTime result;
        string text = Convert.ToString(value, CultureInfo.InvariantCulture).Trim().Replace('-', '/');
        return DateTime.TryParseExact(text, new string[] { "yyyy/M/d", "yyyy/M/d H:mm:ss", "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss" },
            CultureInfo.InvariantCulture, DateTimeStyles.None, out result) ? (DateTime?)result.Date : null;
    }

    public static RowChoice FindRow(object dates, int lastRow, DateTime day, bool date1904)
    {
        int empty = 0;
        Array values = dates as Array;
        for (int row = 11; row <= lastRow; row++)
        {
            object value = values == null ? dates : values.GetValue(values.GetLowerBound(0) + row - 11, values.GetLowerBound(1));
            if (value == null || Convert.ToString(value) == "")
            {
                if (empty == 0) empty = row;
            }
            else if (ParseDate(value, date1904) == day.Date) return new RowChoice(row, false);
        }
        return new RowChoice(empty != 0 ? empty : Math.Max(11, lastRow + 1), true);
    }

    public static Dictionary<string, object[]> ReadRecords(object raw)
    {
        Array values = raw as Array;
        if (values == null || values.Rank != 2 || values.GetLength(1) != 8)
            throw new InvalidDataException("源数据需要至少包含 A–I 九列；B 列必须有测点名称。");
        Dictionary<string, object[]> result = new Dictionary<string, object[]>(StringComparer.Ordinal);
        int firstCol = values.GetLowerBound(1);
        for (int row = values.GetLowerBound(0); row <= values.GetUpperBound(0); row++)
        {
            string name = Convert.ToString(values.GetValue(row, firstCol), CultureInfo.InvariantCulture).Trim();
            if (name.Length == 0) continue;
            // B:I source block: G, F, H, I -> output B, C, D, E.
            result[name] = new object[] { values.GetValue(row, firstCol + 5), values.GetValue(row, firstCol + 4),
                values.GetValue(row, firstCol + 6), values.GetValue(row, firstCol + 7) };
        }
        if (result.Count == 0) throw new InvalidDataException("源数据 B 列没有有效测点名称。");
        return result;
    }

    public static void ValidatePaths(string source, string template, string output)
    {
        if (!File.Exists(source)) throw new IOException("源数据文件不存在。");
        if (!File.Exists(template)) throw new IOException("目标模板文件不存在。");
        string ext = Path.GetExtension(source).ToLowerInvariant();
        if (!new List<string> { ".xls", ".xlsx", ".csv", ".tsv", ".txt", ".xml", ".html", ".htm" }.Contains(ext))
            throw new IOException("源数据需为 Excel、CSV、制表符文本、HTML 或 Excel XML 文件。");
        ext = Path.GetExtension(template).ToLowerInvariant();
        if (ext != ".xls" && ext != ".xlsx") throw new IOException("模板必须是 Excel 工作簿。");
        if (!String.Equals(ext, Path.GetExtension(output), StringComparison.OrdinalIgnoreCase))
            throw new IOException("输出文件扩展名必须与模板一致。");
        string full = Path.GetFullPath(output);
        if (String.Equals(full, Path.GetFullPath(source), StringComparison.OrdinalIgnoreCase) ||
            String.Equals(full, Path.GetFullPath(template), StringComparison.OrdinalIgnoreCase))
            throw new IOException("输出不能覆盖源数据或目标模板，请另存新文件。");
        if (!Directory.Exists(Path.GetDirectoryName(full))) throw new IOException("输出文件夹不存在。");
        if (Directory.Exists(full)) throw new IOException("请选择输出文件名，而非文件夹。");
    }
}

public class MainForm : Form
{
    private readonly TextBox source = new TextBox(), template = new TextBox(), output = new TextBox();
    private readonly DateTimePicker picker = new DateTimePicker();
    private readonly ProgressBar progress = new ProgressBar();
    private readonly TextBox log = new TextBox();
    private readonly Label status = new Label();
    private readonly Button start = new Button(), openFolder = new Button();
    private readonly List<Control> inputs = new List<Control>();
    private bool running;
    private string completedOutput;

    public MainForm()
    {
        Text = "钢筋数据助手 · 独立版 2.0.1";
        Font = new Font("Microsoft YaHei UI", 10F);
        Size = new Size(860, 660); MinimumSize = new Size(760, 580);
        StartPosition = FormStartPosition.CenterScreen;
        AutoScaleMode = AutoScaleMode.Dpi;
        TableLayoutPanel panel = new TableLayoutPanel();
        panel.Dock = DockStyle.Fill; panel.Padding = new Padding(20);
        panel.ColumnCount = 3; panel.RowCount = 10;
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        for (int i = 2; i <= 5; i++) panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        Controls.Add(panel);
        Label title = new Label(); title.Text = "钢筋数据助手"; title.Font = new Font(Font.FontFamily, 21F, FontStyle.Bold); title.Dock = DockStyle.Fill;
        panel.Controls.Add(title, 0, 0); panel.SetColumnSpan(title, 3);
        Label subtitle = new Label(); subtitle.Text = "无需 Python、Excel 或 WPS · 文件只在本机处理"; subtitle.Dock = DockStyle.Fill;
        panel.Controls.Add(subtitle, 0, 1); panel.SetColumnSpan(subtitle, 3);
        AddPath(panel, 2, "源数据文件", source, PickSource); source.Name = "sourcePath";
        AddPath(panel, 3, "目标计算表模板", template, PickTemplate); template.Name = "templatePath";
        AddPath(panel, 4, "输出文件", output, PickOutput); output.Name = "outputPath";
        Label dateLabel = new Label(); dateLabel.Text = "源数据日期"; dateLabel.Dock = DockStyle.Fill; dateLabel.TextAlign = ContentAlignment.MiddleLeft;
        panel.Controls.Add(dateLabel, 0, 5);
        picker.Name = "sourceDate"; picker.Format = DateTimePickerFormat.Custom; picker.CustomFormat = "yyyy-MM-dd";
        picker.Value = DateTime.Today; picker.Dock = DockStyle.Fill; picker.DropDownAlign = LeftRightAlignment.Right;
        picker.KeyPress += delegate(object sender, KeyPressEventArgs e) { e.Handled = true; };
        picker.KeyDown += delegate(object sender, KeyEventArgs e) { if (e.KeyCode != Keys.F4) e.SuppressKeyPress = true; };
        panel.Controls.Add(picker, 1, 5); inputs.Add(picker);
        Label dateHint = new Label(); dateHint.Text = "点击箭头选日期"; dateHint.Dock = DockStyle.Fill; dateHint.TextAlign = ContentAlignment.MiddleCenter;
        panel.Controls.Add(dateHint, 2, 5);
        FlowLayoutPanel actions = new FlowLayoutPanel(); actions.Dock = DockStyle.Fill;
        start.Name = "start"; start.Text = "开始处理"; start.AutoSize = true; start.Click += StartProcessing;
        openFolder.Text = "打开输出文件夹"; openFolder.AutoSize = true; openFolder.Enabled = false;
        openFolder.Click += delegate { if (completedOutput != null) System.Diagnostics.Process.Start("explorer.exe", "/select,\"" + completedOutput + "\""); };
        actions.Controls.Add(start); actions.Controls.Add(openFolder); inputs.Add(start);
        panel.Controls.Add(actions, 0, 6); panel.SetColumnSpan(actions, 3);
        progress.Name = "progress"; progress.Dock = DockStyle.Fill; progress.Maximum = 100;
        panel.Controls.Add(progress, 0, 7); panel.SetColumnSpan(progress, 3);
        log.Name = "log"; log.Multiline = true; log.ReadOnly = true; log.ScrollBars = ScrollBars.Vertical; log.Dock = DockStyle.Fill;
        panel.Controls.Add(log, 0, 8); panel.SetColumnSpan(log, 3);
        status.Text = "请选择源数据、模板、输出位置和日期。"; status.Dock = DockStyle.Fill; status.TextAlign = ContentAlignment.MiddleLeft;
        panel.Controls.Add(status, 0, 9); panel.SetColumnSpan(status, 3);
        FormClosing += delegate(object sender, FormClosingEventArgs e)
        {
            if (running) { e.Cancel = true; MessageBox.Show(this, "正在处理，请等待处理和保存完成后再关闭。", "正在处理"); }
        };
    }

    private void AddPath(TableLayoutPanel panel, int row, string name, TextBox text, EventHandler handler)
    {
        Label label = new Label(); label.Text = name; label.Dock = DockStyle.Fill; label.TextAlign = ContentAlignment.MiddleLeft;
        text.ReadOnly = true; text.Dock = DockStyle.Fill;
        Button button = new Button(); button.Text = "选择文件…"; button.Dock = DockStyle.Fill; button.Click += handler;
        panel.Controls.Add(label, 0, row); panel.Controls.Add(text, 1, row); panel.Controls.Add(button, 2, row); inputs.Add(button);
    }

    private string ChooseInput(string title, bool sourceFile = false)
    {
        using (OpenFileDialog dialog = new OpenFileDialog())
        {
            dialog.Title = title;
            dialog.Filter = sourceFile ? "源数据（自动识别内容格式）|*.xls;*.xlsx;*.csv;*.tsv;*.txt;*.xml;*.htm;*.html|所有文件|*.*" : "Excel 工作簿|*.xls;*.xlsx";
            dialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            return dialog.ShowDialog(this) == DialogResult.OK ? dialog.FileName : null;
        }
    }
    private void PickSource(object sender, EventArgs e) { string path = ChooseInput("选择源数据（读取第一个工作表）", true); if (path != null) source.Text = path; }
    private void PickTemplate(object sender, EventArgs e)
    {
        string path = ChooseInput("选择目标计算表模板");
        if (path == null) return;
        template.Text = path;
        if (output.Text.Length == 0 || !String.Equals(Path.GetExtension(output.Text), Path.GetExtension(path), StringComparison.OrdinalIgnoreCase))
            output.Text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "钢筋计_写入结果" + Path.GetExtension(path));
    }
    private void PickOutput(object sender, EventArgs e)
    {
        if (template.Text.Length == 0) { MessageBox.Show(this, "请先选择目标模板，以确定输出格式。"); return; }
        using (SaveFileDialog dialog = new SaveFileDialog())
        {
            string ext = Path.GetExtension(template.Text);
            dialog.Title = "选择输出文件"; dialog.Filter = "与模板相同的 Excel 格式|*" + ext; dialog.DefaultExt = ext.TrimStart('.');
            dialog.FileName = Path.GetFileName(output.Text);
            dialog.InitialDirectory = Path.GetDirectoryName(output.Text);
            if (dialog.ShowDialog(this) == DialogResult.OK) output.Text = dialog.FileName;
        }
    }

    private void Report(int percent, string message)
    {
        BeginInvoke((Action)delegate { progress.Value = Math.Max(0, Math.Min(100, percent)); log.AppendText(message + "\r\n"); });
    }

    private void StartProcessing(object sender, EventArgs e)
    {
        if (String.IsNullOrWhiteSpace(source.Text) || String.IsNullOrWhiteSpace(template.Text) || String.IsNullOrWhiteSpace(output.Text))
        { MessageBox.Show(this, "请选择源数据、目标模板及输出文件。"); return; }
        try { DataRules.ValidatePaths(source.Text, template.Text, output.Text); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "文件设置有误", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
        if (File.Exists(output.Text) && MessageBox.Show(this, "输出文件已存在，是否覆盖？\r\n" + output.Text,
            "确认覆盖", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        string sourcePath = source.Text, templatePath = template.Text, outputPath = output.Text;
        DateTime day = picker.Value.Date;
        running = true; completedOutput = null; openFolder.Enabled = false;
        foreach (Control input in inputs) input.Enabled = false;
        progress.Value = 0; status.Text = "正在处理，请勿操作本次处理的工作簿。";
        log.AppendText("—— 开始处理，日期：" + day.ToString("yyyy-MM-dd") + " ——\r\n");
        Thread worker = new Thread(delegate()
        {
            int count = 0; string failure = null;
            try { count = SpreadsheetProcessor.Process(sourcePath, templatePath, outputPath, day, Report); }
            catch (Exception error) { failure = error.Message; }
            BeginInvoke((Action)delegate
            {
                running = false;
                foreach (Control input in inputs) input.Enabled = true;
                if (failure == null)
                {
                    completedOutput = outputPath; openFolder.Enabled = true;
                    status.Text = "处理完成：" + count + " 个测点。";
                    MessageBox.Show(this, status.Text + "\r\n\r\n保存位置：\r\n" + outputPath, "处理完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    status.Text = "处理失败，详见日志；原始输入文件保持不变。";
                    log.AppendText("处理失败：" + failure + "\r\n");
                    MessageBox.Show(this, failure + "\r\n\r\n请确认文件没有打开密码或写保护，输出位置可写；若为公式错误，请查看日志中的公式信息。", "处理失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            });
        });
        worker.SetApartmentState(ApartmentState.STA); worker.Start();
    }
}

public static class Program
{
    [STAThread]
    public static void Main()
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
}
