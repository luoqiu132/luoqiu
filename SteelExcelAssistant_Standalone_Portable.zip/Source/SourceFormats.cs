using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using ExcelDataReader;
using HtmlAgilityPack;
using NPOI.SS.UserModel;

public sealed class InputInfo
{
    public string Kind;
    public string Description;
    public Encoding Encoding;
    public bool GuessedUtf8;
    public InputInfo(string kind, string description, Encoding encoding) { Kind = kind; Description = description; Encoding = encoding; }
    public bool IsWorkbook { get { return Kind == "ole" || Kind == "zip"; } }
}

public static class SourceFormats
{
    public static InputInfo Inspect(string path)
    {
        byte[] bytes = new byte[16384]; int length;
        using (FileStream stream = File.OpenRead(path)) length = stream.Read(bytes, 0, bytes.Length);
        if (length == 0) return new InputInfo("empty", "空文件（0 字节）", null);
        byte[] ole = { 0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1 };
        if (length >= 8 && ole.SequenceEqual(bytes.Take(8))) return new InputInfo("ole", "标准 .xls / OLE 工作簿", null);
        if (length >= 4 && bytes[0] == 0x50 && bytes[1] == 0x4b && (bytes[2] == 3 || bytes[2] == 5 || bytes[2] == 7))
            return new InputInfo("zip", ".xlsx / ZIP 工作簿", null);
        if (length >= 4 && bytes[0] == 9 && (bytes[1] == 0 || bytes[1] == 2 || bytes[1] == 4 || bytes[1] == 8))
            return new InputInfo("biff", "旧式 Excel / BIFF 数据流", null);
        Encoding encoding = null; bool guessedUtf8 = false;
        if (length >= 2 && bytes[0] == 0xff && bytes[1] == 0xfe) encoding = Encoding.Unicode;
        else if (length >= 2 && bytes[0] == 0xfe && bytes[1] == 0xff) encoding = Encoding.BigEndianUnicode;
        else if (length >= 3 && bytes[0] == 0xef && bytes[1] == 0xbb && bytes[2] == 0xbf) encoding = new UTF8Encoding(false, true);
        else if (length >= 4 && bytes[1] == 0 && bytes[3] == 0) encoding = Encoding.Unicode;
        else if (length >= 4 && bytes[0] == 0 && bytes[2] == 0) encoding = Encoding.BigEndianUnicode;
        if (encoding == null)
        {
            if (bytes.Take(length).Any(b => b == 0)) return new InputInfo("binary", "未识别的二进制文件", null);
            string ascii = Encoding.ASCII.GetString(bytes, 0, length);
            Match declared = Regex.Match(ascii, @"(?:charset\s*=\s*[""']?|encoding\s*=\s*[""'])([A-Za-z0-9_-]+)", RegexOptions.IgnoreCase);
            if (declared.Success)
            {
                try { encoding = Encoding.GetEncoding(declared.Groups[1].Value, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback); }
                catch (ArgumentException) { throw new InvalidDataException("文件声明了不支持的字符编码：" + declared.Groups[1].Value); }
            }
            if (encoding == null)
            {
                try { new UTF8Encoding(false, true).GetDecoder().GetCharCount(bytes, 0, length, false); encoding = new UTF8Encoding(false, true); guessedUtf8 = true; }
                catch (DecoderFallbackException) { encoding = Encoding.GetEncoding(54936, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback); }
            }
        }
        char[] decoded = new char[encoding.GetMaxCharCount(length)];
        int charCount = encoding.GetDecoder().GetChars(bytes, 0, length, decoded, 0, false);
        string text = new string(decoded, 0, charCount).TrimStart('\ufeff', ' ', '\t', '\r', '\n');
        if (text.IndexOf("urn:schemas-microsoft-com:office:spreadsheet", StringComparison.OrdinalIgnoreCase) >= 0)
            return new InputInfo("xml", "Excel 2003 XML 表格", encoding) { GuessedUtf8 = guessedUtf8 };
        if (Regex.IsMatch(text, @"<(?:html|table|tr|!doctype\s+html)\b", RegexOptions.IgnoreCase))
            return new InputInfo("html", "HTML 网页表格", encoding) { GuessedUtf8 = guessedUtf8 };
        return new InputInfo("text", "文本分隔表格（CSV / 制表符）", encoding) { GuessedUtf8 = guessedUtf8 };
    }

    public static IWorkbook OpenWorkbook(Stream stream, string path, string role, InputInfo info)
    {
        if (!info.IsWorkbook)
            throw new InvalidDataException(role + "「" + Path.GetFileName(path) + "」实际格式为：" + info.Description +
                "。\r\n目标模板需要标准 .xls 或 .xlsx 工作簿，不能仅把文本/网页文件改成 .xls 扩展名。");
        try { return WorkbookFactory.Create(stream); }
        catch (Exception ex)
        {
            throw new InvalidDataException(role + "「" + Path.GetFileName(path) + "」无法读取。检测格式：" + info.Description +
                "。文件可能已加密、损坏或不是完整工作簿。\r\n详细信息：" + ex.Message, ex);
        }
    }

    private static object Value(string text)
    {
        text = text.Trim();
        if (text.Length == 0) return null;
        double number;
        if (double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out number) && !double.IsNaN(number) && !double.IsInfinity(number)) return number;
        if (Regex.IsMatch(text, @"^[+-]?\d{1,3}(,\d{3})+(\.\d+)?$") &&
            double.TryParse(text, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out number)) return number;
        return text;
    }

    private static Dictionary<string, object[]> FromRows(List<List<string>> rows)
    {
        if (rows.Count < 2 || !rows.Any(row => row.Count >= 9)) throw new InvalidDataException("源数据需要第一行表头及至少 A–I 九列数据。");
        Dictionary<string, object[]> result = new Dictionary<string, object[]>(StringComparer.Ordinal);
        for (int index = 1; index < rows.Count; index++)
        {
            List<string> row = rows[index];
            string name = row.Count > 1 ? row[1].Trim() : "";
            if (name.Length == 0) continue;
            if (row.Count < 9) throw new InvalidDataException("源数据第 " + (index + 1) + " 行不足九列，未写入结果。");
            result[name] = new object[] { Value(row[6]), Value(row[5]), Value(row[7]), Value(row[8]) };
        }
        if (result.Count == 0) throw new InvalidDataException("源数据 B 列没有有效测点名称。");
        return result;
    }

    private static List<List<string>> Delimited(string text, char separator)
    {
        List<List<string>> rows = new List<List<string>>(); List<string> row = new List<string>();
        StringBuilder cell = new StringBuilder(); bool quoted = false;
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (c == '"')
            {
                if (quoted && i + 1 < text.Length && text[i + 1] == '"') { cell.Append('"'); i++; }
                else if (quoted || cell.Length == 0) quoted = !quoted;
                else cell.Append(c);
            }
            else if (!quoted && (c == separator || c == '\n' || c == '\r'))
            {
                row.Add(cell.ToString()); cell.Length = 0;
                if (c != separator)
                {
                    if (row.Any(value => value.Trim().Length > 0)) rows.Add(row);
                    row = new List<string>();
                    if (c == '\r' && i + 1 < text.Length && text[i + 1] == '\n') i++;
                }
            }
            else cell.Append(c);
        }
        if (quoted) throw new InvalidDataException("文本源数据存在未闭合的双引号。");
        if (cell.Length > 0 || row.Count > 0)
        {
            row.Add(cell.ToString());
            if (row.Any(value => value.Trim().Length > 0)) rows.Add(row);
        }
        return rows;
    }

    private static List<List<string>> ReadText(string text)
    {
        List<List<string>> best = null; int score = -1;
        foreach (char separator in new char[] { '\t', ',', ';' })
        {
            List<List<string>> rows;
            try { rows = Delimited(text, separator); } catch (InvalidDataException) { continue; }
            int current = rows.Count(row => row.Count >= 9);
            if (current > score) { best = rows; score = current; }
        }
        if (best == null || score == 0) throw new InvalidDataException("已识别为文本，但没有找到至少九列的 CSV 或制表符数据。请提供仪器源文件以便适配。");
        return best;
    }

    private static int Span(string text)
    {
        int count;
        if (!int.TryParse(text, out count) || count < 1 || count > 16384) throw new InvalidDataException("表格包含无效的合并单元格或列索引。");
        return count;
    }

    private static List<List<string>> ReadHtml(string text)
    {
        HtmlDocument document = new HtmlDocument(); document.LoadHtml(text);
        HtmlNodeCollection tables = document.DocumentNode.SelectNodes("//table");
        if (tables == null) throw new InvalidDataException("HTML 源文件没有 table 表格。");
        foreach (HtmlNode table in tables)
        {
            List<List<string>> rows = new List<List<string>>();
            Dictionary<int, int> pending = new Dictionary<int, int>();
            HtmlNodeCollection tr = table.SelectNodes(".//tr"); if (tr == null) continue;
            foreach (HtmlNode node in tr.Where(n => n.Ancestors("table").FirstOrDefault() == table))
            {
                HtmlNodeCollection cells = node.SelectNodes("./th|./td"); if (cells == null) continue;
                HashSet<int> occupied = new HashSet<int>(pending.Keys);
                foreach (int key in pending.Keys.ToArray()) { if (--pending[key] == 0) pending.Remove(key); }
                List<string> values = new List<string>(); int column = 0;
                foreach (HtmlNode cell in cells)
                {
                    while (occupied.Contains(column)) { values.Add(""); column++; }
                    string value = HtmlEntity.DeEntitize(cell.InnerText).Replace('\u00a0', ' ').Trim();
                    int across = Span(cell.GetAttributeValue("colspan", "1")); int down = Span(cell.GetAttributeValue("rowspan", "1"));
                    for (int j = 0; j < across; j++)
                    {
                        if (column >= 16384) throw new InvalidDataException("HTML 源数据列数超出范围。");
                        values.Add(j == 0 ? value : "");
                        if (down > 1) pending[column] = down - 1;
                        column++;
                    }
                }
                while (occupied.Any(c => c >= column)) { values.Add(""); column++; }
                rows.Add(values);
            }
            if (rows.Count >= 2 && rows.Any(row => row.Count >= 9)) return rows;
        }
        throw new InvalidDataException("HTML 源文件中没有包含表头及至少九列数据的表格。");
    }

    private static List<List<string>> ReadXml(string text)
    {
        XmlReaderSettings settings = new XmlReaderSettings(); settings.DtdProcessing = DtdProcessing.Prohibit; settings.XmlResolver = null;
        XmlDocument document = new XmlDocument(); document.XmlResolver = null;
        using (XmlReader reader = XmlReader.Create(new StringReader(text.TrimStart('\ufeff')), settings)) document.Load(reader);
        XmlNamespaceManager ns = new XmlNamespaceManager(document.NameTable);
        const string ss = "urn:schemas-microsoft-com:office:spreadsheet"; ns.AddNamespace("ss", ss);
        XmlNode table = document.SelectSingleNode("/ss:Workbook/ss:Worksheet[1]/ss:Table", ns);
        if (table == null) throw new InvalidDataException("Excel XML 源数据没有第一个工作表。");
        List<List<string>> rows = new List<List<string>>();
        foreach (XmlNode row in table.SelectNodes("ss:Row", ns))
        {
            List<string> values = new List<string>();
            foreach (XmlNode cell in row.SelectNodes("ss:Cell", ns))
            {
                XmlAttribute indexed = cell.Attributes["Index", ss];
                if (indexed != null)
                {
                    int index = Span(indexed.Value);
                    if (index <= values.Count) throw new InvalidDataException("Excel XML 源数据列索引顺序错误。");
                    while (values.Count < index - 1) values.Add("");
                }
                XmlNode data = cell.SelectSingleNode("ss:Data", ns); values.Add(data == null ? "" : data.InnerText);
                XmlAttribute merged = cell.Attributes["MergeAcross", ss];
                int merge;
                if (merged != null && int.TryParse(merged.Value, out merge))
                {
                    if (merge < 0 || merge > 16384 - values.Count) throw new InvalidDataException("Excel XML 源数据合并列数超出范围。");
                    for (int j = 0; j < merge; j++) values.Add("");
                }
            }
            rows.Add(values);
        }
        return rows;
    }

    private static Dictionary<string, object[]> ReadLegacy(string path)
    {
        using (Stream stream = File.OpenRead(path))
        using (IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream, new ExcelReaderConfiguration { FallbackEncoding = Encoding.GetEncoding(936) }))
        {
            List<List<string>> rows = new List<List<string>>();
            while (reader.Read())
            {
                List<string> values = new List<string>();
                for (int c = 0; c < reader.FieldCount; c++) values.Add(Convert.ToString(reader.GetValue(c), CultureInfo.InvariantCulture));
                rows.Add(values);
            }
            return FromRows(rows);
        }
    }

    public static Dictionary<string, object[]> ReadExport(string path, InputInfo info)
    {
        if (info.Kind == "biff") return ReadLegacy(path);
        if (info.Encoding == null) throw new InvalidDataException("无法识别仪器源数据格式：" + info.Description + "。请提供源文件以便适配。");
        string text;
        try { text = File.ReadAllText(path, info.Encoding); }
        catch (DecoderFallbackException)
        {
            if (!info.GuessedUtf8) throw;
            text = File.ReadAllText(path, Encoding.GetEncoding(54936, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback));
        }
        text = text.TrimStart('\ufeff');
        List<List<string>> rows = info.Kind == "html" ? ReadHtml(text) : info.Kind == "xml" ? ReadXml(text) : ReadText(text);
        return FromRows(rows);
    }
}
