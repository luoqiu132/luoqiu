using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using BorderStyle = NPOI.SS.UserModel.BorderStyle;

public static class StandaloneTests
{
    private static int checks;
    private static readonly DateTime Day = new DateTime(2026, 10, 27);
    private static void Check(bool condition, string label)
    {
        if (!condition) throw new Exception("FAIL: " + label);
        checks++; Console.WriteLine("PASS: " + label);
    }
    private static IWorkbook NewBook(bool xlsx) { return xlsx ? (IWorkbook)new XSSFWorkbook() : new HSSFWorkbook(); }
    private static void Save(IWorkbook book, string path)
    {
        using (FileStream stream = File.Create(path)) book.Write(stream, true);
    }
    private static void DateCell(ISheet sheet, int row, DateTime day, bool date1904)
    {
        IRow r = sheet.GetRow(row) ?? sheet.CreateRow(row);
        r.CreateCell(0).SetCellValue(DateUtil.GetExcelDate(day, date1904));
    }
    private static void RunFormat(bool xlsx, bool date1904)
    {
        string label = (xlsx ? "xlsx" : "xls") + (date1904 ? " 1904" : " 1900");
        string dir = Path.Combine(Path.GetTempPath(), "steel-test-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(dir);
        string ext = xlsx ? ".xlsx" : ".xls";
        string source = Path.Combine(dir, "source" + ext), template = Path.Combine(dir, "template" + ext), output = Path.Combine(dir, "result" + ext);
        try
        {
            using (IWorkbook book = NewBook(xlsx))
            {
                ISheet sheet = book.CreateSheet("data");
                IRow header = sheet.CreateRow(0);
                for (int c = 0; c < 9; c++) header.CreateCell(c).SetCellValue("header");
                string[] names = { "A", "B", "A", "C", "D" };
                double[,] values = { { 99, 0.9, 19, 29 }, { 200, 2.5, 21, 31 }, { 100, 1.2, 20, 30 }, { 300, 3, 22, 32 }, { 400, 4, 23, 33 } };
                for (int r = 1; r <= names.Length; r++)
                {
                    IRow row = sheet.CreateRow(r); row.CreateCell(1).SetCellValue(names[r - 1]);
                    for (int c = 0; c < 4; c++) row.CreateCell(5 + c).SetCellValue(values[r - 1, c]);
                }
                Save(book, source);
            }
            using (IWorkbook book = NewBook(xlsx))
            {
                if (date1904) ((XSSFWorkbook)book).GetCTWorkbook().workbookPr.date1904 = true;
                ISheet a = book.CreateSheet("A"); a.CreateRow(10);
                DateCell(a, 11, Day, date1904);
                ICellStyle style = book.CreateCellStyle(); style.BorderBottom = BorderStyle.Thick;
                ICell b = a.GetRow(11).CreateCell(1); b.CellStyle = style; b.SetCellFormula("123*2");
                a.GetRow(11).CreateCell(5).SetCellFormula("B12*C12");
                a.CreateRow(0).CreateCell(7).SetCellValue("preserve merged title");
                a.AddMergedRegion(new CellRangeAddress(0, 0, 7, 8));
                ISheet bb = book.CreateSheet("B");
                DateCell(bb, 10, Day.AddDays(-1), date1904); bb.CreateRow(11); DateCell(bb, 12, Day.AddDays(1), date1904);
                book.CreateSheet("D");
                book.CreateSheet("untouched").CreateRow(0).CreateCell(0).SetCellValue("keep me");
                Save(book, template);
            }
            byte[] sourceBefore = File.ReadAllBytes(source), templateBefore = File.ReadAllBytes(template);
            File.WriteAllText(output, "prior output");
            int progress = 0; string messages = "";
            int count = SpreadsheetProcessor.Process(source, template, output, Day, delegate(int p, string text) { progress = p; messages += text + "\n"; });
            Check(count == 3 && progress == 100, label + ": writes three matching sheets to completed output");
            using (FileStream stream = File.OpenRead(output))
            using (IWorkbook book = WorkbookFactory.Create(stream))
            {
                ISheet a = book.GetSheet("A");
                Check(a.GetRow(10).GetCell(1) == null && Math.Abs(a.GetRow(11).GetCell(1).NumericCellValue - 1.2) < 0.00001,
                    label + ": matching date wins over earlier blank; final source record used");
                Check(a.GetRow(11).GetCell(1).CellType == CellType.Numeric && a.GetRow(11).GetCell(2).NumericCellValue == 100 &&
                      a.GetRow(11).GetCell(3).NumericCellValue == 20 && a.GetRow(11).GetCell(4).NumericCellValue == 30,
                      label + ": G/F/H/I mapped to B/C/D/E, old formula replaced");
                ICell formula = a.GetRow(11).GetCell(5);
                Check(formula.CellFormula == "B12*C12" && Math.Abs(formula.NumericCellValue - 120) < 0.00001,
                      label + ": formula preserved and recalculated without Excel");
                Check(a.NumMergedRegions == 1 && a.GetRow(11).GetCell(1).CellStyle.BorderBottom == BorderStyle.Thick,
                      label + ": merged cells and existing styles preserved");
                ICell newDate = book.GetSheet("B").GetRow(11).GetCell(0);
                Check(DataRules.ParseDate(newDate.NumericCellValue, date1904) == Day && newDate.CellStyle.GetDataFormatString() == "yyyy/m/d",
                      label + ": first blank receives proper date and format");
                Check(book.GetSheet("D").GetRow(10).GetCell(1).NumericCellValue == 4,
                      label + ": empty target starts at row 11");
                Check(book.GetSheet("untouched").GetRow(0).GetCell(0).StringCellValue == "keep me" && messages.Contains("没有同名"),
                      label + ": skipped data stays intact and unmatched point is logged");
            }
            Check(sourceBefore.SequenceEqual(File.ReadAllBytes(source)) && templateBefore.SequenceEqual(File.ReadAllBytes(template)),
                  label + ": input files byte-for-byte unchanged");
            Check(!Directory.GetFiles(dir, ".steel_*").Any(), label + ": no temporary result remains");
            bool rejected = false;
            try { SpreadsheetProcessor.Process(source, template, source, Day, delegate { }); } catch (IOException) { rejected = true; }
            Check(rejected, label + ": cannot overwrite input");
        }
        finally { Directory.Delete(dir, true); }
    }
    [STAThread]
    public static void Main()
    {
        RunFormat(false, false); RunFormat(true, false); RunFormat(true, true);
        RunFailureCases();
        Application.EnableVisualStyles();
        using (MainForm form = new MainForm())
        {
            form.Show(); Application.DoEvents();
            Check(((TextBox)form.Controls.Find("sourcePath", true)[0]).ReadOnly, "UI: file chooser is readonly");
            DateTimePicker picker = (DateTimePicker)form.Controls.Find("sourceDate", true)[0];
            picker.Value = new DateTime(2024, 2, 29);
            Check(picker.Value.Day == 29 && picker.Format == DateTimePickerFormat.Custom, "UI: calendar selects leap day");
            Check(form.Controls.Find("progress", true)[0] is ProgressBar && ((TextBox)form.Controls.Find("log", true)[0]).Multiline,
                  "UI: progress and process log exist");
            form.Close();
        }
        Console.WriteLine("Completed: " + checks + " checks passed without Office or Python.");
    }

    private static void RunFailureCases()
    {
        string dir = Path.Combine(Path.GetTempPath(), "steel-fail-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(dir);
        string source = Path.Combine(dir, "source.xls"), template = Path.Combine(dir, "template.xls"), output = Path.Combine(dir, "output.xls");
        try
        {
            using (IWorkbook book = new HSSFWorkbook())
            {
                ISheet s = book.CreateSheet("data"); s.CreateRow(0).CreateCell(8).SetCellValue("stress");
                IRow row = s.CreateRow(1); row.CreateCell(1).SetCellValue("A");
                for (int col = 5; col < 9; col++) row.CreateCell(col).SetCellValue(col);
                Save(book, source);
            }
            foreach (string mode in new string[] { "unmatched", "protected", "unsupported_formula" })
            {
                using (IWorkbook book = new HSSFWorkbook())
                {
                    ISheet sheet = book.CreateSheet(mode == "unmatched" ? "other" : "A");
                    if (mode == "protected") sheet.ProtectSheet("test");
                    if (mode == "unsupported_formula") sheet.CreateRow(10).CreateCell(5).SetCellFormula("PHONETIC(\"test\")");
                    Save(book, template);
                }
                File.WriteAllText(output, "existing result stays unchanged");
                bool failed = false;
                try { SpreadsheetProcessor.Process(source, template, output, Day, delegate { }); }
                catch (InvalidDataException) { failed = true; }
                Check(failed, mode + ": processing fails explicitly");
                Check(File.ReadAllText(output) == "existing result stays unchanged" && !Directory.GetFiles(dir, ".steel_*").Any(),
                      mode + ": existing output preserved and temporary file cleaned");
            }
        }
        finally { Directory.Delete(dir, true); }
    }
}
