using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;

public static class SourceFormatTests
{
    private static readonly DateTime Day = new DateTime(2026, 10, 27);
    private static void Record(BinaryWriter writer, ushort type, Action<BinaryWriter> write)
    {
        using (MemoryStream data = new MemoryStream())
        {
            using (BinaryWriter record = new BinaryWriter(data, Encoding.ASCII, true)) write(record);
            writer.Write(type); writer.Write((ushort)data.Length); writer.Write(data.ToArray());
        }
    }
    private static byte[] Biff2()
    {
        using (MemoryStream stream = new MemoryStream())
        using (BinaryWriter writer = new BinaryWriter(stream))
        {
            Record(writer, 0x0009, w => { w.Write((ushort)2); w.Write((ushort)0x0010); });
            Record(writer, 0x0000, w => { w.Write((ushort)0); w.Write((ushort)2); w.Write((ushort)0); w.Write((ushort)9); });
            Record(writer, 0x0004, w => { w.Write((ushort)0); w.Write((ushort)8); w.Write(new byte[3]); w.Write((byte)6); w.Write(Encoding.ASCII.GetBytes("stress")); });
            Record(writer, 0x0004, w => { w.Write((ushort)1); w.Write((ushort)1); w.Write(new byte[3]); w.Write((byte)1); w.Write((byte)'A'); });
            double[] values = { 100, 1.2, 20, 30 };
            for (int c = 0; c < 4; c++)
            {
                int column = c;
                Record(writer, 0x0003, w => { w.Write((ushort)1); w.Write((ushort)(5 + column)); w.Write(new byte[3]); w.Write(values[column]); });
            }
            Record(writer, 0x000a, w => { });
            return stream.ToArray();
        }
    }
    private static void WorkbookFile(string path, string name, bool template)
    {
        using (IWorkbook book = new HSSFWorkbook())
        {
            ISheet sheet = book.CreateSheet(template ? name : "source");
            if (template) sheet.CreateRow(10).CreateCell(5).SetCellFormula("B11*C11");
            else
            {
                sheet.CreateRow(0).CreateCell(8).SetCellValue("stress");
                IRow row = sheet.CreateRow(1); row.CreateCell(1).SetCellValue(name);
                for (int c = 5; c < 9; c++) row.CreateCell(c).SetCellValue(c);
            }
            using (Stream stream = File.Create(path)) book.Write(stream, true);
        }
    }
    private static void Exercise(string dir, string label, byte[] bytes, string name, double resistance, string kind, Action<bool, string> check)
    {
        string source = Path.Combine(dir, label + (label == "csv" ? ".csv" : ".xls"));
        string template = Path.Combine(dir, "template.xls"), output = Path.Combine(dir, "result.xls");
        File.WriteAllBytes(source, bytes); WorkbookFile(template, name, true);
        byte[] before = File.ReadAllBytes(source); string log = "";
        check(SourceFormats.Inspect(source).Kind == kind, label + ": content format identified despite extension");
        int count = SpreadsheetProcessor.Process(source, template, output, Day, delegate(int p, string text) { log += text; });
        using (Stream stream = File.OpenRead(output))
        using (IWorkbook book = WorkbookFactory.Create(stream))
        {
            IRow row = book.GetSheet(name).GetRow(10);
            check(count == 1 && Math.Abs(row.GetCell(1).NumericCellValue - 1.2) < 0.000001 && Math.Abs(row.GetCell(2).NumericCellValue - resistance) < 0.000001,
                  label + ": last record parsed and mapped to numeric measurement cells");
            check(Math.Abs(row.GetCell(5).NumericCellValue - 1.2 * resistance) < 0.000001,
                  label + ": template formula calculated from imported values");
        }
        check(log.Contains(Path.GetFileName(source)) && log.Contains("检测格式") && before.SequenceEqual(File.ReadAllBytes(source)),
              label + ": source named in format log and input bytes unchanged");
    }
    public static void Run(Action<bool, string> check)
    {
        string dir = Path.Combine(Path.GetTempPath(), "steel-exports-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(dir);
        try
        {
            string header = "时间\t测点\tC\tD\tE\t电阻\t电阻比\t温度\t应力\r\n";
            string rows = "x\t测点甲\t\t\t\t99\t0.9\t19\t29\r\nx\t测点甲\t\t\t\t100\t1.2\t20\t30\r\n";
            byte[] utf16 = Encoding.Unicode.GetPreamble().Concat(Encoding.Unicode.GetBytes(header + rows)).ToArray();
            Exercise(dir, "utf16-tsv", utf16, "测点甲", 100, "text", check);
            Exercise(dir, "gbk-tsv", Encoding.GetEncoding(936).GetBytes(header + rows), "测点甲", 100, "text", check);
            string csv = "time,name,C,D,E,resistance,ratio,temp,stress\r\n\"instrument\"\" note\nline\",\"测点,甲\",,,,\"1,000.5\",1.2,20,30\r\n";
            Exercise(dir, "csv", Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(csv)).ToArray(), "测点,甲", 1000.5, "text", check);
            string html = "<html><head><meta charset='gb2312'></head><body><table><tr><td><table>" +
                "<tr>" + String.Join("", Enumerable.Range(0, 9).Select(i => "<th>header</th>")) + "</tr>" +
                "<tr><td>x<td>测点&amp;甲<td><td><td><td>99<td>0.9<td>19<td>29</tr>" +
                "<tr><td>x<td>测点&amp;甲<td colspan='3'><td>100<td>1.2<td>20<td>30</tr>" +
                "</table></td></tr></table></body></html>";
            Exercise(dir, "gbk-html", Encoding.GetEncoding(936).GetBytes(html), "测点&甲", 100, "html", check);
            string xml = "<?xml version='1.0' encoding='UTF-8'?><Workbook xmlns='urn:schemas-microsoft-com:office:spreadsheet' xmlns:ss='urn:schemas-microsoft-com:office:spreadsheet'><Worksheet ss:Name='source'><Table>" +
                "<Row><Cell ss:Index='9'><Data ss:Type='String'>stress</Data></Cell></Row>" +
                "<Row><Cell ss:Index='2'><Data ss:Type='String'>测点甲</Data></Cell><Cell ss:Index='6'><Data ss:Type='Number'>100</Data></Cell><Cell><Data ss:Type='Number'>1.2</Data></Cell><Cell><Data ss:Type='Number'>20</Data></Cell><Cell><Data ss:Type='Number'>30</Data></Cell></Row>" +
                "</Table></Worksheet></Workbook>";
            Exercise(dir, "spreadsheet-xml", Encoding.UTF8.GetBytes(xml), "测点甲", 100, "xml", check);
            using (HSSFWorkbook book = new HSSFWorkbook())
            {
                ISheet sheet = book.CreateSheet("source"); sheet.CreateRow(0).CreateCell(8).SetCellValue("stress");
                IRow row = sheet.CreateRow(1); row.CreateCell(1).SetCellValue("A");
                row.CreateCell(5).SetCellValue(100); row.CreateCell(6).SetCellValue(1.2); row.CreateCell(7).SetCellValue(20); row.CreateCell(8).SetCellValue(30);
                Exercise(dir, "raw-biff8", book.GetBytes(), "A", 100, "biff", check);
            }
            Exercise(dir, "raw-biff2", Biff2(), "A", 100, "biff", check);
            string boundaryPath = Path.Combine(dir, "utf8-boundary.xls");
            File.WriteAllBytes(boundaryPath, Encoding.UTF8.GetBytes(new string('a', 16383) + "测"));
            check(SourceFormats.Inspect(boundaryPath).Encoding.CodePage == 65001, "UTF8 sample cut inside multibyte character still recognized correctly");
            Exercise(dir, "late-gbk", Encoding.GetEncoding(936).GetBytes("time\tname\tc\td\te\tr\tk\tt\ts\r\n" + new string(' ', 17000) + "\r\n" + rows), "测点甲", 100, "text", check);
            foreach (string mode in new string[] { "empty", "unknown-binary", "html-template", "xml-dtd" })
            {
                string source = Path.Combine(dir, "bad-source.xls"), template = Path.Combine(dir, "bad-template.xls"), output = Path.Combine(dir, "preserved.xls");
                WorkbookFile(source, "A", false); WorkbookFile(template, "A", true);
                if (mode == "empty") File.WriteAllBytes(source, new byte[0]);
                if (mode == "unknown-binary") File.WriteAllBytes(source, new byte[] { 1, 2, 0, 4, 0, 9 });
                if (mode == "html-template") File.WriteAllText(template, html);
                if (mode == "xml-dtd") File.WriteAllText(source, "<!DOCTYPE Workbook [<!ENTITY x SYSTEM 'file:///not-to-be-read'>]>" + xml.Substring(xml.IndexOf("<Workbook")));
                File.WriteAllText(output, "prior output"); string message = "";
                try { SpreadsheetProcessor.Process(source, template, output, Day, delegate { }); }
                catch (InvalidDataException error) { message = error.Message; }
                string role = mode == "html-template" ? "目标模板" : "源数据";
                string file = mode == "html-template" ? "bad-template.xls" : "bad-source.xls";
                check(message.Contains(role) && message.Contains(file), mode + ": error identifies input role and filename");
                check(File.ReadAllText(output) == "prior output", mode + ": invalid format cannot replace prior output");
            }
        }
        finally { Directory.Delete(dir, true); }
    }
}
