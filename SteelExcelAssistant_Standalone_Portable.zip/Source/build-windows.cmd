@echo off
setlocal
cd /d "%~dp0"
set "STEEL_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%STEEL_CSC%" set "STEEL_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%STEEL_CSC%" goto missing
set "STEEL_REF=/reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Core.dll"
set "STEEL_FACADE=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\Facades\netstandard.dll"
if not exist "%STEEL_FACADE%" set "STEEL_FACADE=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\Facades\netstandard.dll"
if not exist "%STEEL_FACADE%" goto missing
set "STEEL_REF=%STEEL_REF% /reference:"%STEEL_FACADE%""
for %%F in ("..\*.dll") do call set "STEEL_REF=%%STEEL_REF%% /reference:"%%~fF""
"%STEEL_CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /out:"..\SteelExcelAssistant-rebuilt.exe" %STEEL_REF% DesktopApp.cs SpreadsheetProcessor.cs
if errorlevel 1 goto failed
copy /y "..\SteelExcelAssistant.exe.config" "..\SteelExcelAssistant-rebuilt.exe.config" >nul
echo Rebuilt EXE is in the parent folder. No Python or Excel was used.
pause
exit /b 0
:missing
echo .NET Framework 4.7.2 or later is required. Update Windows first.
pause
exit /b 1
:failed
echo Build failed. Read the error above.
pause
exit /b 1
