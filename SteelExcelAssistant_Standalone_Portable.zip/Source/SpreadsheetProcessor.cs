using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using NPOI.SS.UserModel;

public static class SpreadsheetProcessor
{
    private static object ReadCell(ICell cell, IFormulaEvaluator evaluator)
    {
        if (cell == null) return null;
        if (cell.CellType == CellType.Formula)
        {
            CellValue evaluated = evaluator.Evaluate(cell);
            switch (evaluated.CellType)
            {
                case CellType.Numeric: return evaluated.NumberValue;
                case CellType.String: return evaluated.StringValue;
                case CellType.Boolean: return evaluated.BooleanValue;
                case CellType.Blank: return null;
                default: throw new InvalidDataException("源数据含有无法计算的公式：" + cell.Address.FormatAsString());
            }
        }
        switch (cell.CellType)
        {
            case CellType.Numeric: return cell.NumericCellValue;
            case CellType.String: return cell.StringCellValue;
            case CellType.Boolean: return cell.BooleanCellValue;
            case CellType.Blank: return null;
            default: throw new InvalidDataException("单元格包含错误值：" + cell.Address.FormatAsString());
        }
    }

    private static Dictionary<string, object[]> LoadSource(string path, Action<int, string> report)
    {
        InputInfo info = SourceFormats.Inspect(path);
        report(3, "源数据「" + Path.GetFileName(path) + "」检测格式：" + info.Description);
        if (!info.IsWorkbook)
        {
            try { return SourceFormats.ReadExport(path, info); }
            catch (Exception ex) { throw new InvalidDataException("源数据「" + Path.GetFileName(path) + "」读取失败（" + info.Description + "）：\r\n" + ex.Message, ex); }
        }
        using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
        using (IWorkbook book = SourceFormats.OpenWorkbook(stream, path, "源数据", info))
        {
            ISheet sheet = book.GetSheetAt(0);
            if (sheet.LastRowNum < 1) throw new InvalidDataException("源数据需要表头和至少一行数据。");
            bool hasNineColumns = false;
            foreach (IRow row in sheet) if (row.LastCellNum >= 9) { hasNineColumns = true; break; }
            if (!hasNineColumns) throw new InvalidDataException("源数据第一个工作表至少需要 A–I 九列。");
            IFormulaEvaluator evaluator = book.GetCreationHelper().CreateFormulaEvaluator();
            Dictionary<string, object[]> records = new Dictionary<string, object[]>(StringComparer.Ordinal);
            for (int index = 1; index <= sheet.LastRowNum; index++)
            {
                IRow row = sheet.GetRow(index);
                if (row == null) continue;
                string name = Convert.ToString(ReadCell(row.GetCell(1), evaluator), CultureInfo.InvariantCulture).Trim();
                if (name.Length == 0) continue;
                records[name] = new object[] { ReadCell(row.GetCell(6), evaluator), ReadCell(row.GetCell(5), evaluator),
                    ReadCell(row.GetCell(7), evaluator), ReadCell(row.GetCell(8), evaluator) };
            }
            if (records.Count == 0) throw new InvalidDataException("源数据 B 列没有有效测点名称。");
            return records;
        }
    }

    private static ICell EnsureCell(ISheet sheet, int rowIndex, int column)
    {
        IRow row = sheet.GetRow(rowIndex);
        IRow previous = rowIndex > 0 ? sheet.GetRow(rowIndex - 1) : null;
        if (row == null)
        {
            row = sheet.CreateRow(rowIndex);
            if (previous != null) row.Height = previous.Height;
        }
        ICell cell = row.GetCell(column);
        if (cell == null)
        {
            cell = row.CreateCell(column);
            ICell previousCell = previous == null ? null : previous.GetCell(column);
            if (previousCell != null) cell.CellStyle = previousCell.CellStyle;
        }
        return cell;
    }

    private static void SetValue(ICell cell, object value)
    {
        // Replacing a formula must remove its old formula record as well as set a cached value.
        if (cell.CellType == CellType.Formula) cell.SetCellType(CellType.Blank);
        if (value == null) cell.SetCellType(CellType.Blank);
        else if (value is double) cell.SetCellValue((double)value);
        else if (value is bool) cell.SetCellValue((bool)value);
        else cell.SetCellValue(Convert.ToString(value, CultureInfo.InvariantCulture));
    }

    public static int Process(string source, string template, string output, DateTime day, Action<int, string> report)
    {
        DataRules.ValidatePaths(source, template, output);
        source = Path.GetFullPath(source); template = Path.GetFullPath(template); output = Path.GetFullPath(output);
        report(2, "直接读取源文件，无需 Excel 或 WPS……");
        Dictionary<string, object[]> records = LoadSource(source, report);
        report(8, "读取到 " + records.Count + " 个测点；同名测点采用最后一条记录。");
        string temporary = Path.Combine(Path.GetDirectoryName(output), ".steel_" + Guid.NewGuid().ToString("N") + Path.GetExtension(template));
        int written = 0;
        try
        {
            InputInfo templateInfo = SourceFormats.Inspect(template);
            report(9, "目标模板「" + Path.GetFileName(template) + "」检测格式：" + templateInfo.Description);
            using (FileStream templateStream = new FileStream(template, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (IWorkbook book = SourceFormats.OpenWorkbook(templateStream, template, "目标模板", templateInfo))
            {
                IFormulaEvaluator evaluator = book.GetCreationHelper().CreateFormulaEvaluator();
                bool date1904 = book.IsDate1904();
                HashSet<string> matched = new HashSet<string>(StringComparer.Ordinal);
                Dictionary<int, ICellStyle> dateStyles = new Dictionary<int, ICellStyle>();
                for (int index = 0; index < book.NumberOfSheets; index++)
                {
                    ISheet sheet = book.GetSheetAt(index);
                    string name = sheet.SheetName;
                    int percent = 10 + (80 * (index + 1) / Math.Max(1, book.NumberOfSheets));
                    if (!records.ContainsKey(name)) { report(percent, "跳过工作表：" + name + "（无对应源数据）"); continue; }
                    if (sheet.Protect) throw new InvalidDataException("工作表「" + name + "」已启用写保护，请先使用无保护的模板副本。");
                    int last = 9;
                    for (int rowIndex = sheet.LastRowNum; rowIndex >= 10; rowIndex--)
                    {
                        IRow row = sheet.GetRow(rowIndex);
                        ICell cell = row == null ? null : row.GetCell(0);
                        object value = ReadCell(cell, evaluator);
                        if (value != null && Convert.ToString(value) != "") { last = rowIndex; break; }
                    }
                    int found = -1, firstEmpty = -1;
                    for (int rowIndex = 10; rowIndex <= last; rowIndex++)
                    {
                        IRow row = sheet.GetRow(rowIndex);
                        object value = ReadCell(row == null ? null : row.GetCell(0), evaluator);
                        if (value == null || Convert.ToString(value) == "") { if (firstEmpty < 0) firstEmpty = rowIndex; }
                        else if (DataRules.ParseDate(value, date1904) == day.Date) { found = rowIndex; break; }
                    }
                    bool isNew = found < 0;
                    if (isNew) found = firstEmpty >= 0 ? firstEmpty : last + 1;
                    if (isNew)
                    {
                        ICell dateCell = EnsureCell(sheet, found, 0);
                        if (dateCell.CellType == CellType.Formula) dateCell.SetCellType(CellType.Blank);
                        dateCell.SetCellValue(DateUtil.GetExcelDate(day.Date, date1904));
                        int styleIndex = dateCell.CellStyle.Index;
                        if (!dateStyles.ContainsKey(styleIndex))
                        {
                            ICellStyle style = book.CreateCellStyle(); style.CloneStyleFrom(dateCell.CellStyle);
                            style.DataFormat = book.CreateDataFormat().GetFormat("yyyy/m/d");
                            dateStyles[styleIndex] = style;
                        }
                        dateCell.CellStyle = dateStyles[styleIndex];
                    }
                    for (int col = 0; col < 4; col++) SetValue(EnsureCell(sheet, found, col + 1), records[name][col]);
                    matched.Add(name); written++;
                    report(percent, name + "：" + (isNew ? "新增日期" : "更新已有日期") + "，第 " + (found + 1) + " 行，B–E 列写入完成。");
                }
                foreach (string name in records.Keys)
                    if (!matched.Contains(name)) report(91, "提示：测点「" + name + "」没有同名目标工作表，未写入。");
                if (written == 0) throw new InvalidDataException("没有匹配的测点工作表，未生成结果。请核对源数据 B 列与目标工作表名称。");
                report(94, "正在使用内置引擎计算公式……");
                try { evaluator.ClearAllCachedResultValues(); evaluator.EvaluateAll(); }
                catch (Exception ex) { throw new InvalidDataException("模板含有内置引擎无法计算的公式，结果未保存。详细信息：" + ex.Message, ex); }
                report(98, "正在保存结果……");
                using (FileStream result = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None)) book.Write(result, true);
            }
            if (File.Exists(output)) File.Replace(temporary, output, null); else File.Move(temporary, output);
            report(100, "完成：已写入 " + written + " 个测点。\r\n保存位置：" + output);
            return written;
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
}
