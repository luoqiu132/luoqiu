using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

public sealed class InstallerForm : Form
{
    private readonly Button install = new Button();
    private readonly TextBox log = new TextBox();
    private readonly ProgressBar progress = new ProgressBar();
    private bool busy;

    public InstallerForm()
    {
        Text = "安装钢筋数据助手（独立版）";
        Font = new Font("Microsoft YaHei UI", 10F);
        Size = new Size(660, 440); MinimumSize = new Size(600, 400);
        StartPosition = FormStartPosition.CenterScreen;
        TableLayoutPanel panel = new TableLayoutPanel(); panel.Dock = DockStyle.Fill; panel.Padding = new Padding(20);
        panel.RowCount = 5; panel.ColumnCount = 1;
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(panel);
        Label title = new Label(); title.Text = "钢筋数据助手 · 独立版"; title.Font = new Font(Font.FontFamily, 20F, FontStyle.Bold); title.Dock = DockStyle.Fill;
        panel.Controls.Add(title);
        Label info = new Label(); info.Text = "无需 Python、Excel 或 WPS；安装无需联网。\r\n安装到当前用户文件夹，并自动创建桌面快捷方式。"; info.Dock = DockStyle.Fill;
        panel.Controls.Add(info);
        install.Text = "安装并创建桌面快捷方式"; install.AutoSize = true; install.Anchor = AnchorStyles.Left;
        install.Click += BeginInstall; panel.Controls.Add(install);
        progress.Dock = DockStyle.Fill; panel.Controls.Add(progress);
        log.Multiline = true; log.ReadOnly = true; log.ScrollBars = ScrollBars.Vertical; log.Dock = DockStyle.Fill; panel.Controls.Add(log);
        FormClosing += delegate(object sender, FormClosingEventArgs e) { if (busy) e.Cancel = true; };
    }

    private void Report(int value, string text)
    {
        BeginInvoke((Action)delegate { progress.Value = Math.Min(100, Math.Max(0, value)); log.AppendText(text + "\r\n"); });
    }

    private void BeginInstall(object sender, EventArgs e)
    {
        // Windows 10/11 use the system .NET Framework; no Python or Office is involved.
        using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full"))
        {
            if (key == null || Convert.ToInt32(key.GetValue("Release", 0)) < 461808)
            { MessageBox.Show(this, "系统需要 .NET Framework 4.7.2 或更高版本。请先完成 Windows 系统更新后重试。", "系统组件版本不足"); return; }
        }
        busy = true; install.Enabled = false;
        Thread worker = new Thread(delegate()
        {
            string baseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SteelExcelAssistantStandalone");
            string installDir = Path.Combine(baseDir, "2.0.0-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6));
            string shortcutPath = null; bool completed = false;
            try
            {
                Directory.CreateDirectory(installDir);
                Report(1, "安装位置：" + installDir);
                using (Stream payload = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
                using (ZipArchive zip = new ZipArchive(payload, ZipArchiveMode.Read))
                {
                    int index = 0;
                    foreach (ZipArchiveEntry entry in zip.Entries)
                    {
                        string dest = Path.GetFullPath(Path.Combine(installDir, entry.FullName));
                        if (!dest.StartsWith(Path.GetFullPath(installDir) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                            throw new IOException("安装包包含无效路径。");
                        if (entry.FullName.EndsWith("/")) { Directory.CreateDirectory(dest); continue; }
                        Directory.CreateDirectory(Path.GetDirectoryName(dest));
                        using (Stream input = entry.Open()) using (FileStream output = new FileStream(dest, FileMode.CreateNew, FileAccess.Write)) input.CopyTo(output);
                        index++; Report(5 + index * 80 / zip.Entries.Count, "已安装：" + entry.FullName);
                    }
                }
                string exe = Path.Combine(installDir, "SteelExcelAssistant.exe");
                if (!File.Exists(exe)) throw new IOException("主程序未能正确解压。");
                string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                if (String.IsNullOrEmpty(desktop) || !Directory.Exists(desktop)) throw new IOException("无法找到当前用户的桌面文件夹。");
                shortcutPath = Path.Combine(desktop, "钢筋数据助手（独立版）.lnk");
                if (File.Exists(shortcutPath)) shortcutPath = Path.Combine(desktop, "钢筋数据助手（独立版）-" + DateTime.Now.ToString("MMddHHmmss") + ".lnk");
                dynamic shell = null, shortcut = null;
                try
                {
                    shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
                    shortcut = shell.CreateShortcut(shortcutPath);
                    shortcut.TargetPath = exe; shortcut.WorkingDirectory = installDir;
                    shortcut.IconLocation = exe + ",0"; shortcut.Description = "钢筋数据助手：无需 Python、Excel 或 WPS";
                    shortcut.Save();
                }
                finally
                {
                    if (shortcut != null && Marshal.IsComObject(shortcut)) Marshal.FinalReleaseComObject(shortcut);
                    if (shell != null && Marshal.IsComObject(shell)) Marshal.FinalReleaseComObject(shell);
                }
                if (!File.Exists(shortcutPath)) throw new IOException("桌面快捷方式创建失败。程序位置：" + exe);
                completed = true;
                Report(100, "安装完成。桌面快捷方式：" + shortcutPath);
                BeginInvoke((Action)delegate
                {
                    busy = false; install.Text = "安装完成";
                    MessageBox.Show(this, "桌面快捷方式已创建：\r\n" + shortcutPath + "\r\n\r\n将打开桌面文件夹并选中快捷方式。", "安装完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    try { Process.Start("explorer.exe", "/select,\"" + shortcutPath + "\""); Process.Start(exe); }
                    catch (Exception error) { MessageBox.Show(this, "程序已安装，请双击桌面快捷方式启动。\r\n" + error.Message); }
                });
            }
            catch (Exception error)
            {
                string text = error.Message;
                Report(0, "安装失败：" + text);
                BeginInvoke((Action)delegate { busy = false; install.Enabled = true; MessageBox.Show(this, text, "安装失败", MessageBoxButtons.OK, MessageBoxIcon.Error); });
            }
            finally
            {
                if (!completed)
                {
                    if (shortcutPath != null && File.Exists(shortcutPath)) try { File.Delete(shortcutPath); } catch { }
                    if (Directory.Exists(installDir)) try { Directory.Delete(installDir, true); } catch { }
                }
            }
        });
        worker.SetApartmentState(ApartmentState.STA); worker.Start();
    }

    [STAThread]
    public static void Main()
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new InstallerForm());
    }
}
